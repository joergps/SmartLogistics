/**
 * @file main.c
 * <!------------------------------------------------------------------------>
 * @brief @ref REF "WiMOD LoRaWAN (TM) Example Code"
 *
 * @par Project:
 * <!------------------------------------------------------------------------>
 * <!--
 * @par Description:
 *
 * This example shows how to get started with iM880A via HCI. The radio module
 * will be activated direct or OTA and send out a dummy telegramms 
 * periodically.
 * -->
 * <!------------------------------------------------------------------------>
 * <!--
 * @remarks
 * -->
 * <!------------------------------------------------------------------------
 * Copyright (c) 2015
 * IMST GmbH
 * Carl-Friedrich Gauss Str. 2
 * 47475 Kamp-Lintfort
 * -------------------------------------------------------------------------->
 * @author Mathias Hater (MH), IMST
 * <!------------------------------------------------------------------------
 * Target OS:    none
 * Target CPU:   EFM32
 * Compiler:     IAR C/C++ Compiler
 * -------------------------------------------------------------------------->
 * @internal
 * @par Revision History:
 * <PRE>
 * ---------------------------------------------------------------------------
 * Version | Date       | Author | Comment
 * ---------------------------------------------------------------------------
 * 0.1     | 26.03.2015 | MH     | Created
 *
 * </PRE>

 Copyright (c) 2015 IMST GmbH.
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are NOT permitted without prior written permission
 of the IMST GmbH.

 THIS SOFTWARE IS PROVIDED BY THE IMST GMBH AND CONTRIBUTORS ``AS IS'' AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE IMST GMBH OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 THIS SOFTWARE IS CLASSIFIED AS: CONFIDENTIAL

 LoRaWAN is a trademark of the LoRa Alliance

 *******************************************************************************/

// board support package
#include "bsp.h"

// EFM32 device files
#include "em_chip.h"
#include "em_cmu.h"

// HCI wrapper file
#include "iM880A_RadioInterface.h"

// needed for delays
#include "PDDDelayTimer.h"


//------------------------------------------------------------------------------
//
//	Section Defines
//
//------------------------------------------------------------------------------

#define TX_LENGTH                       16
#define POWERUP_DELAY                   500         // ms
#define TX_DELAY                        10000       // ms
#define DEVICE_ADDR                     0x00000002


// select activation method
//
#define ACTIVATION_METHOD_DIRECT        1
//#define ACTIVATION_METHOD_OTA           1

// select telegram type
//
//#define UNCONFIRMED_DATA_TELEGRAMS      1
#define CONFIRMED_DATA_TELEGRAMS        1
     
//------------------------------------------------------------------------------
//
//	Section Typedefs
//
//------------------------------------------------------------------------------

typedef enum
{
    POWER_UP                        = 0x0001,
    MSG_SENT                        = 0x0002,
    MSG_RECEIVED                    = 0x0004,
    ACK_RECEIVED                    = 0x0008,
    
}TMainEventCode;


//------------------------------------------------------------------------------
//
//	Section RAM
//
//------------------------------------------------------------------------------

UINT32 mainEvent = 0;


static UINT8 txBuffer[TX_LENGTH] = {0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF };  

#if defined(ACTIVATION_METHOD_DIRECT)

// Direct Activation Parameters

static UINT8 nwkSessionKey[KEY_LEN] = {0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF }; 

static UINT8 appSessionKey[KEY_LEN] = {0xFF, 0xEE, 0xDD, 0xCC, 0xBB, 0xAA, 0x99, 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11, 0x00 }; 

#else

// OTA Parameters

static UINT8 appEUI[EUI_LEN]        = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x11, 0x22 }; 

static UINT8 deviceEUI[EUI_LEN]     = {0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28 }; 

static UINT8 deviceKey[KEY_LEN]     = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10 }; 

#endif


//------------------------------------------------------------------------------
//
//	Section Code
//
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
//
//	CbDevMgmtHCIResponse
//
//------------------------------------------------------------------------------
//!
//! @brief: Handle HCI response messages of SAP DEVMGMT_ID
//!
//------------------------------------------------------------------------------
static void
CbDevMgmtHCIResponse(UINT8          msgID, 
                     UINT8*         msg,
                     UINT8          length)
{
    switch(msgID)
    {
        case    DEVMGMT_MSG_PING_RSP:
                // handle ping response here
                break;

        default:
                // handle unsupported MsgIDs here
                break;
    }
}


//------------------------------------------------------------------------------
//
//	CbMsgIndication
//
//------------------------------------------------------------------------------
//!
//! @brief: Handle TX/RX/ACK radio messages
//!
//------------------------------------------------------------------------------
static void
CbMsgIndication(UINT8*          msg,
                UINT8           length,
                TRadioFlags     trxFlags)
{
    if(trxFlags == trx_RXDone)
    {
        // Radio Msg received
        mainEvent |= MSG_RECEIVED;  
    }
    else if (trxFlags == trx_TXDone)
    {
        // TX was successfull
        mainEvent |= MSG_SENT;
    }
    else if (trxFlags == trx_ACKDone)
    {
        // Ack received
        mainEvent |= ACK_RECEIVED;
    }
}


//------------------------------------------------------------------------------
//
//	CbLoRaWANHCIResponse
//
//------------------------------------------------------------------------------
//!
//! @brief: Handle HCI response messages of SAP LORAWAN_ID
//!
//------------------------------------------------------------------------------
static void
CbLoRaWANHCIResponse(UINT8          msgID, 
                     UINT8*         msg,
                     UINT8          length)
{
    switch(msgID)
    {
        case    LORAWAN_MSG_ACTIVATE_DEVICE_RSP:
                break;
                
        case    LORAWAN_MSG_SET_JOIN_PARAM_RSP:
                break;

        case    LORAWAN_MSG_SEND_UDATA_RSP:
                break;
                
        case    LORAWAN_MSG_SEND_CDATA_RSP:
                break;
                    
        case    LORAWAN_MSG_GET_STATUS_RSP:
                break;
                    
        default:
                // handle unsupported MsgIDs here
                break;
    }
}



//------------------------------------------------------------------------------
//
//	System_Setup
//
//------------------------------------------------------------------------------
//!
//! @brief: Top Level Setup routine
//!
//------------------------------------------------------------------------------
void System_Setup(void)
{        
    // Init external clock
    CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFXO);    
    CMU_ClockEnable(cmuClock_HFPER, true);
    
    // Init delay timer
    PDDDelayTimer_Setup();            
}





//------------------------------------------------------------------------------
//
//	main
//
//------------------------------------------------------------------------------

int main(void)
{
    // Initialize �C
    CHIP_Init();
    
    // Initalizing System
    System_Setup();    
    
    // Initialize radio driver
    iM880A_Init();    
    
    // Register callback functions
    iM880A_RegisterRadioCallbacks(CbMsgIndication, CbLoRaWANHCIResponse, CbDevMgmtHCIResponse);
        
    // Wait for radio to power up
    PDDDelayTimer_Delay_ms(POWERUP_DELAY);
    
    // Test connection
    iM880A_PingRequest();
    

#if defined(ACTIVATION_METHOD_DIRECT) 
     
    // Direct Device Activation
    //
    iM880A_DirectDeviceActivation(DEVICE_ADDR, nwkSessionKey, appSessionKey);
    
#else
    
    // Wireless Network Activation (OTA)
    //
    iM880A_SetJoinParameters(appEUI, deviceEUI, deviceKey);
        
    iM880A_JoinNetworkRequest();
    
#endif
    
    
    while(1)    
    {
        // Active delay
        PDDDelayTimer_Delay_ms(TX_DELAY);

#if defined(UNCONFIRMED_DATA_TELEGRAMS)   
        
        // Unreliable Data Transmission               
        if(iM880A_SendUDataTelegram(txBuffer, TX_LENGTH) != WiMODLR_RESULT_OK)
               ; // handle faults

#elif defined(CONFIRMED_DATA_TELEGRAMS)
        
        // Confirmed Data Transmission       
        if(iM880A_SendCDataTelegram(txBuffer, TX_LENGTH) != WiMODLR_RESULT_OK)
               ; // handle faults

#endif
    }

}



