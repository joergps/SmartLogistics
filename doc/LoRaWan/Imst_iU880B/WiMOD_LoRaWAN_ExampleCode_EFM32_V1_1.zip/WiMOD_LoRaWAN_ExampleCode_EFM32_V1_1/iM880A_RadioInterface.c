/**
 * @file iM880A_RadioInterface.c
 * <!------------------------------------------------------------------------>
 * @brief @ref REF "WiMOD LoRaWAN (TM) Example Code"
 *
 * @par Project:
 * <!------------------------------------------------------------------------>
 * <!--
 * @par Description:
 *
 *  [Description]
 * -->
 * <!--
 *  @ref [extdocname] "more..."
 *  -->
 * <!------------------------------------------------------------------------>
 * <!--
 * @remarks
 * - [...]
 * - [...]
 * -->
 * <!------------------------------------------------------------------------
 * Copyright (c) 2015
 * IMST GmbH
 * Carl-Friedrich Gauss Str. 2
 * 47475 Kamp-Lintfort
 * -------------------------------------------------------------------------->
 * @author Mathias Hater (MH), IMST
 * <!------------------------------------------------------------------------
 * Target OS:    none
 * Target CPU:   EFM32
 * Compiler:     IAR C/C++ Compiler
 * -------------------------------------------------------------------------->
 * @internal
 * @par Revision History:
 * <PRE>
 * ---------------------------------------------------------------------------
 * Version | Date       | Author | Comment
 * ---------------------------------------------------------------------------
 * 0.1     | 22.01.2015 | MH     | Created
 * 0.2     | 07.08.2015 | MH     | Bugfix in iM880A_SendUDataTelegram() &
 *                                 iM880A_SendCDataTelegram() functions
 *
 * </PRE>

 Copyright (c) 2015 IMST GmbH.
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are NOT permitted without prior written permission
 of the IMST GmbH.

 THIS SOFTWARE IS PROVIDED BY THE IMST GMBH AND CONTRIBUTORS ``AS IS'' AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE IMST GMBH OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 THIS SOFTWARE IS CLASSIFIED AS: CONFIDENTIAL

 LoRaWAN is a trademark of the LoRa Alliance

 *******************************************************************************/

     
#include "ComSlip.h"
#include "CRC16.h"
#include "RadioDefs.h"
#include "PDDDelayTimer.h"
#include "iM880A_RadioInterface.h"


//------------------------------------------------------------------------------
//
//	Section RAM
//
//------------------------------------------------------------------------------

TWiMODLR_HCIMessage TxMessage;
TWiMODLR_HCIMessage RxMessage;


TRadioInterfaceCbMsgIndication          cbMsgIndication;
TRadioInterfaceCbLoRaWANHCIResponse     cbLoRaWANHCIResponse;
TRadioInterfaceCbDevMgmtHCIResponse     cbDevMgmtHCIResponse;




//------------------------------------------------------------------------------
//
//  SendHCIMessage
//
//  @brief  Send a HCI message to the radio module (with or without payload)
//
//------------------------------------------------------------------------------

int
iM880A_SendHCIMessage(UINT8 sapID, UINT8 msgID, UINT8* payload, UINT16 length)
{
    // 1. check parameter
    //
    // 1.1 check length
    //
    if(length > WIMODLR_HCI_MSG_PAYLOAD_SIZE)
    {
        return WiMODLR_RESULT_PAYLOAD_LENGTH_ERROR;
    }

    // 2.  init TxMessage
    //
    // 2.1 init SAP ID
    //
    TxMessage.SapID = sapID;

    // 2.2 init Msg ID
    //
    TxMessage.MsgID = msgID;

    // 2.3 copy payload, if present
    //
    if(payload && length)
    {
        UINT8*  dstPtr  = TxMessage.Payload;
        int     n       = (int)length;

        // copy bytes
        while(n--)
            *dstPtr++ = *payload++;
    }

    // 3. Calculate CRC16 over header and optional payload
    //
    UINT16 crc16 = CRC16_Calc(&TxMessage.SapID, length + WIMODLR_HCI_MSG_HEADER_SIZE, CRC16_INIT_VALUE);

    // 3.1 get 1's complement
    //
    crc16 = ~crc16;

    // 3.2 attach CRC16 and correct length, lobyte first
    //
    TxMessage.Payload[length++] = LOBYTE(crc16);
    TxMessage.Payload[length++] = HIBYTE(crc16);

    // 4. forward message to SLIP layer
    //    - start transmission with SAP ID
    //    - correct length by header size

    if (ComSlip_SendMessage(&TxMessage.SapID, length + WIMODLR_HCI_MSG_HEADER_SIZE))
    {
        // ok !
        return WiMODLR_RESULT_OK;
    }

    // error - SLIP layer couldn't sent message
    return -1;
}





//------------------------------------------------------------------------------
//
//  iM880A_SendUDataTelegram
//
//  @brief  Send out an unreliable (unconfirmed) data telegram
//
//------------------------------------------------------------------------------

TWiMDLRResultcodes 
iM880A_SendUDataTelegram(UINT8* payload, UINT16 length)
{
    TxMessage.Payload[0] = LORA_MAC_PORT;
    
    if(payload && length)
    {
        UINT8*  dstPtr  = TxMessage.Payload + 1;
        int     n       = (int)length;

        // copy bytes
        while(n--)
            *dstPtr++ = *payload++;
    }
    
    return (TWiMDLRResultcodes) iM880A_SendHCIMessage(LORAWAN_ID, LORAWAN_MSG_SEND_UDATA_REQ, NULL, length + 1);
}



//------------------------------------------------------------------------------
//
//  iM880A_SendCDataTelegram
//
//  @brief  Send out an confirmed data telegram
//
//------------------------------------------------------------------------------

TWiMDLRResultcodes 
iM880A_SendCDataTelegram(UINT8* payload, UINT16 length)
{
    TxMessage.Payload[0] = LORA_MAC_PORT;
    
    if(payload && length)
    {
        UINT8*  dstPtr  = TxMessage.Payload + 1;
        int     n       = (int)length;

        // copy bytes
        while(n--)
            *dstPtr++ = *payload++;
    }
    
    return (TWiMDLRResultcodes) iM880A_SendHCIMessage(LORAWAN_ID, LORAWAN_MSG_SEND_CDATA_REQ, NULL, length + 1);
}


//------------------------------------------------------------------------------
//
//  iM880A_DirectDeviceActivation
//
//  @brief  Perform Direct Activation
//
//------------------------------------------------------------------------------

TWiMDLRResultcodes 
iM880A_DirectDeviceActivation(UINT32 deviceAddress, UINT8* nwkSessionKey, UINT8* appSessionKey)
{
    HTON32(&TxMessage.Payload[0], deviceAddress);
        
    if(nwkSessionKey)
    {
        UINT8*  dstPtr  = TxMessage.Payload + DEVICE_ADDR_LEN;
        int     n       = KEY_LEN;

        // copy bytes
        while(n--)
            *dstPtr++ = *nwkSessionKey++;
    }

    if(appSessionKey)
    {
        UINT8*  dstPtr  = TxMessage.Payload + DEVICE_ADDR_LEN + KEY_LEN;
        int     n       = KEY_LEN;

        // copy bytes
        while(n--)
            *dstPtr++ = *appSessionKey++;
    }
    
    return (TWiMDLRResultcodes) iM880A_SendHCIMessage(LORAWAN_ID, LORAWAN_MSG_ACTIVATE_DEVICE_REQ, NULL, DEVICE_ADDR_LEN + KEY_LEN + KEY_LEN);
}



//------------------------------------------------------------------------------
//
//  iM880A_SetJoinParameters
//
//  @brief  Configure the Join parameters
//
//------------------------------------------------------------------------------

TWiMDLRResultcodes 
iM880A_SetJoinParameters(UINT8* appEUI, UINT8* deviceEUI, UINT8* deviceKey)
{    
        
    if(appEUI)
    {
        UINT8*  dstPtr  = TxMessage.Payload;
        int     n       = EUI_LEN;

        // copy bytes
        while(n--)
            *dstPtr++ = *appEUI++;
    }

    if(deviceEUI)
    {
        UINT8*  dstPtr  = TxMessage.Payload + EUI_LEN;
        int     n       = EUI_LEN;

        // copy bytes
        while(n--)
            *dstPtr++ = *deviceEUI++;
    }
    
    if(deviceKey)
    {
        UINT8*  dstPtr  = TxMessage.Payload + EUI_LEN + EUI_LEN;
        int     n       = KEY_LEN;

        // copy bytes
        while(n--)
            *dstPtr++ = *deviceKey++;
    }
    
    return (TWiMDLRResultcodes) iM880A_SendHCIMessage(LORAWAN_ID, LORAWAN_MSG_SET_JOIN_PARAM_REQ, NULL, EUI_LEN + EUI_LEN + KEY_LEN);
}



//------------------------------------------------------------------------------
//
//  iM880A_JoinNetworkRequest
//
//  @brief   Send out a Join Request message
//
//------------------------------------------------------------------------------

TWiMDLRResultcodes 
iM880A_JoinNetworkRequest(void)
{    
    return (TWiMDLRResultcodes) iM880A_SendHCIMessage(LORAWAN_ID, LORAWAN_MSG_JOIN_NETWORK_REQ, NULL, 0);
}



//------------------------------------------------------------------------------
//
//  iM880A_PingRequest
//
//  @brief  Send ping to check communication link
//
//------------------------------------------------------------------------------

TWiMODLRResult
iM880A_PingRequest()
{
    return (TWiMDLRResultcodes) iM880A_SendHCIMessage(DEVMGMT_ID, DEVMGMT_MSG_PING_REQ, NULL, 0);
}



//------------------------------------------------------------------------------
//
//  iM880A_CbProcessRxMessage
//
//  @brief: Handle incoming HCI messages
//
//------------------------------------------------------------------------------

UINT8*
iM880A_CbProcessRxMessage(UINT8* rxBuffer, UINT16 length)
{
    // 1. check CRC
    if (CRC16_Check(rxBuffer, length, CRC16_INIT_VALUE))
    {
        // 2. check min length, 2 bytes for SapID + MsgID + 2 bytes CRC16
        if(length >= (WIMODLR_HCI_MSG_HEADER_SIZE + WIMODLR_HCI_MSG_FCS_SIZE))
        {
            // add length
            RxMessage.Length = length - (WIMODLR_HCI_MSG_HEADER_SIZE + WIMODLR_HCI_MSG_FCS_SIZE);

            // dispatch completed RxMessage
            // 3. forward message according to SapID / MsgID
            switch(RxMessage.SapID)
            {
                case    DEVMGMT_ID:
                        
                        // forward Msg IDs to application, e.g. ping response
                        (*cbLoRaWANHCIResponse)(RxMessage.MsgID, RxMessage.Payload, length);
                        
                        break;

                case    LORAWAN_ID:
                        // handle TX indications
                        if((RxMessage.MsgID == LORAWAN_MSG_SEND_UDATA_TX_IND)   ||
                           (RxMessage.MsgID == LORAWAN_MSG_SEND_CDATA_TX_IND)   ||
                           (RxMessage.MsgID == LORAWAN_MSG_JOIN_NETWORK_TX_IND))
                        {
                            (*cbMsgIndication)(NULL, 0, trx_TXDone);
                        }
                        // handle RX messages
                        else if((RxMessage.MsgID == LORAWAN_MSG_RECV_UDATA_IND) ||
                                (RxMessage.MsgID == LORAWAN_MSG_RECV_CDATA_IND))
                        {
                            (*cbMsgIndication)(RxMessage.Payload, length, trx_RXDone);
                        }
                        
                        // handle ACKs
                        else if(RxMessage.MsgID == LORAWAN_MSG_RECV_ACK_IND)
                        {
                            (*cbMsgIndication)(NULL, 0, trx_ACKDone);
                        }

                        // handle other responses
                        else
                        {
                            (*cbLoRaWANHCIResponse)(RxMessage.MsgID, RxMessage.Payload, length);
                        }

                        break;

                default:
                        // handle unsupported SapIDs here
                        break;
            }
        }
    }
    else
    {
        // handle CRC error
    }

    // return same buffer again, keep receiver enabled
    return &RxMessage.SapID;
    
}


//------------------------------------------------------------------------------
//
//  iM880A_Init
//
//  @brief: Initialize radio interface
//
//------------------------------------------------------------------------------

void 
iM880A_Init(void)
{
    // Init Slip Layer
    ComSlip_Init();
    ComSlip_RegisterClient(iM880A_CbProcessRxMessage);
    
    // pass first RxBuffer and enable receiver/decoder
    ComSlip_SetRxBuffer(&RxMessage.SapID, (UINT16)WIMODLR_HCI_RX_MESSAGE_SIZE);        
}


//------------------------------------------------------------------------------
//
//  iM880A_RegisterRadioCallbacks
//
//  @brief: Set callback functions for incoming HCI messages
//
//------------------------------------------------------------------------------

void 
iM880A_RegisterRadioCallbacks(TRadioInterfaceCbMsgIndication        cbMsgInd, 
                              TRadioInterfaceCbLoRaWANHCIResponse   cbLoRaWANHCIRsp,
                              TRadioInterfaceCbDevMgmtHCIResponse   cbDevMgmtHCIRsp)             
{
    cbMsgIndication      = cbMsgInd;
    cbLoRaWANHCIResponse = cbLoRaWANHCIRsp;
    cbDevMgmtHCIResponse = cbDevMgmtHCIRsp;
}






