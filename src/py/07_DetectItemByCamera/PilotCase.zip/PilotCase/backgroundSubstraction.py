import cv2

# Laden leeres Bild
emptyImage = cv2.imread('empty.jpg')

# Aufnehmen Auktueller ZUsatnd
camera = cv2.VideoCapture(0)

retval, img = camera.read()

rows,cols,ch = img.shape

M = cv2.getRotationMatrix2D((cols/2,rows/2),180,1)
dst = cv2.warpAffine(img,M,(cols,rows))

# Schreiben Aktuelles Bild
cv2.imwrite('full.jpg',dst)

# Background Substraction
fgbg = cv2.BackgroundSubtractorMOG()
fgmask = fgbg.apply(emptyImage)
fgmask = fgbg.apply(dst)
cv2.imwrite('fullMask_MOG.jpg', fgmask)

mog2 = cv2.BackgroundSubtractorMOG2(500, 16,  False)
mog2mask = mog2.apply(emptyImage)
mog2mask = mog2.apply(dst)
cv2.imwrite('fullMask_MOG2.jpg', mog2mask)


edges = cv2.Canny(emptyImage,100,200)
cv2.imwrite('edges_empty.jpg', edges)

edges2 = cv2.Canny(dst,100,200)
cv2.imwrite('edges_full.jpg', edges2)

# Background Substraction
fgbg = cv2.BackgroundSubtractorMOG()
fgmask = fgbg.apply(edges)
fgmask = fgbg.apply(edges2)
cv2.imwrite('edgesMask_MOG.jpg', fgmask)


d = cv2.absdiff(emptyImage, dst)
cv2.imwrite('DiffImage.jpg', d)
print d.sum()

d = cv2.absdiff(edges, edges2)
cv2.imwrite('DiffImageEdges.jpg', d)


HSVemptyImage = cv2.cvtColor(emptyImage, cv2.COLOR_BGR2HSV);
HSVfullImage = cv2.cvtColor(dst, cv2.COLOR_BGR2HSV);
d = cv2.absdiff(HSVemptyImage, HSVfullImage)
cv2.imwrite('DiffImageHSV.jpg', d)


camera.release()
